import NavBar from "./NavBar";

export default function About()
{
	return(
	<>
	<center>
	<NavBar/>
	</center>
	</>
	);
}