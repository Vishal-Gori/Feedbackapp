// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyA_4llFzNaNO4a6nSZcUoC3U-dqDXECGq4",
  authDomain: "authapp15june23-e6e26.firebaseapp.com",
  projectId: "authapp15june23-e6e26",
  storageBucket: "authapp15june23-e6e26.appspot.com",
  messagingSenderId: "13536741010",
  appId: "1:13536741010:web:e981b102a7ad26f9aa084b"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export default app;